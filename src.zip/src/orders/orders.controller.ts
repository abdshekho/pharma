import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { FindDistributorsDto } from './dto/find-distributors.dto';
import { CheckAvailabilityDto } from './dto/check-availability.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { UserRole } from '@prisma/client';

@Controller('orders')
@UseGuards(JwtAuthGuard, RolesGuard)
export class OrdersController {
  constructor(private readonly service: OrdersService) {}

  @Post()
  @Roles(UserRole.pharmacist)
  create(@Body() dto: CreateOrderDto, @CurrentUser() user: any) {
    return this.service.create(user.id, dto);
  }

  // distributor and products
  @Post('check-availability')
  @Roles(UserRole.pharmacist)
  checkAvailability(@Body() dto: CheckAvailabilityDto) {
    return this.service.checkAvailability(dto);
  }

  @Get('available-distributors')
  @Roles(UserRole.pharmacist)
  findAvailableDistributors(@CurrentUser() user: any, @Query() dto: FindDistributorsDto) {
    return this.service.findAvailableDistributors(user.id, dto);
  }

  @Get()
  @Roles(UserRole.pharmacist, UserRole.distributor, UserRole.admin, UserRole.delivery_staff)
  findAll(@CurrentUser() user: any, @Query('status') status?: string) {
    return this.service.findAll(user.id, user.role, status);
  }

  @Get(':id')
  @Roles(UserRole.pharmacist, UserRole.distributor, UserRole.admin, UserRole.delivery_staff)
  findOne(@Param('id') id: string, @CurrentUser() user: any) {
    return this.service.findOne(id, user.id, user.role);
  }

  @Patch(':id/status')
  @Roles(UserRole.distributor, UserRole.pharmacist, UserRole.admin,UserRole.delivery_staff)
  updateStatus(@Param('id') id: string, @Body() dto: UpdateOrderStatusDto, @CurrentUser() user: any) {
    return this.service.updateStatus(id, user.id, user.role, dto);
  }

  @Patch(':id/assign')
  @Roles(UserRole.distributor)
  updateAssign(
    @Param('id') id: string,
    @CurrentUser() user: any,
    @Body('deliveryStaffId') deliveryStaffId?: string,
  ) {
    return this.service.updateAssign(id, user.id, user.role, deliveryStaffId);
  }
    
}
