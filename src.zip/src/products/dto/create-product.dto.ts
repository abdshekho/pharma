import {
  IsString,
  IsOptional,
  IsUUID,
  IsArray,
  IsEnum,
  IsInt,
  IsDecimal,
  Length,
  Min,
} from "class-validator";
import {
  DosageForm,
  PackUnit,
  PackageType,
  ProductStatus,
} from "@prisma/client";

export class CreateProductDto {
  @IsString()
  @Length(1, 200)
  nameAr!: string;

  @IsOptional()
  @IsString()
  @Length(1, 200)
  nameEn?: string;

  @IsOptional()
  @IsEnum(DosageForm)
  dosageForm?: DosageForm;

  @IsOptional()
  @IsInt()
  @Min(1)
  packSize?: number;

  @IsOptional()
  @IsEnum(PackUnit)
  packUnit?: PackUnit;

  @IsOptional()
  @IsEnum(PackageType)
  packageType?: PackageType;

  @IsOptional()
  @IsString()
  @Length(1, 100)
  barcode?: string;

  @IsOptional()
  @IsString()
  strength?: string;

  @IsOptional()
  @IsString()
  usageInstructions?: string;

  // @IsDecimal()
  // price!: string;

  @IsOptional()
  @IsString()
  imageUrl?: string;

  @IsOptional()
  @IsString()
  brochureUrl?: string;

  @IsOptional()
  @IsArray()
  @IsUUID("all", { each: true })
  drugGroupIds?: string[];

  @IsOptional()
  @IsArray()
  @IsUUID("all", { each: true })
  specializationIds?: string[];

  @IsOptional()
  @IsDecimal()
  companyToDistributorPrice?: string;

  @IsOptional()
  @IsDecimal()
  distributorToPharmacistPrice?: string;

  @IsOptional()
  @IsDecimal()
  pharmacistToConsumerPrice?: string;

  @IsOptional()
  @IsString()
  status?: ProductStatus = "draft";
}
