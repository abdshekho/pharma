import { Controller, Get, Put, Patch, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { UserRole } from '@prisma/client';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserStatus } from '@prisma/client';

@Controller('users')
@UseGuards(JwtAuthGuard, RolesGuard)
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get('inactive')
  @Roles(UserRole.admin)

  findAllInactive(@Query('role') role?: string) {
    return this.usersService.findAllInactive(role);
  }

  @Get('me')
  getMe(@CurrentUser() user: any) {
    return this.usersService.findById(user.id);
  }

  @Get('admin-only')
  @Roles(UserRole.admin)
  adminOnly() {
    return { message: 'Admin only endpoint' };
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    return this.usersService.update(id, updateUserDto);
  }

  @Patch(':id/verify')
  @Roles(UserRole.admin)
  verify(@Param('id') id: string, @CurrentUser() admin: any) {
    return this.usersService.verifyUser(id, admin.id);
  }

  @Delete(':id')
  @Roles(UserRole.admin)
  remove(@Param('id') id: string) {
    return this.usersService.remove(id);
  }
}